export default {
  jwt: {
    secret: 'f47aa56d803a3537b6ae403b619d78dd',
    expiresIn: '1d',
  },
};
